/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Paige Smith
 * CS 490-01
 * Due: 4/6/25
 * This file runs with Homework2_Smith.java main function.
 */

//import for timestamping the output
import java.time.LocalTime;

// Process class to store all information passed in by user
public class Process implements Runnable {
    int id;
    String name;
    int ms;
    // RT = True, NM = false
    boolean type;
    int priority;

    // Constructor for the class
    public Process(int i, String n, int m, boolean t, int p){
        id = i;
        name = n;
        ms = m;
        type = t;
        priority = p;
    }

    // Run the process and display the statistics
    public void run(){
        // Print the start time and process information
        String typeLabel = type ? "Real-Time Process" : "Normal Process";
        String timeStart = LocalTime.now().toString();
        System.out.printf("%-8s %-26s %-2d  %-20s%n", "BEGIN", timeStart, id, typeLabel + " " + name);
        
        try {
            // Simulate executing the process
            Thread.sleep(ms);
        }
        catch (InterruptedException e) {
            // Handle exception
            e.printStackTrace();
        }
        
        // Print the end time of process
        String timeEnd = LocalTime.now().toString();
        System.out.printf("%-8s %-26s %-2d  %-20s%n", "END", timeEnd, id, typeLabel + " " + name);
    }
}
