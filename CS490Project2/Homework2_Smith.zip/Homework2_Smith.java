/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



/**
 *
 * @author Paige Smith
 * CS 490-01 Project 2
 * Due: 4/6/25
 * This file runs with Process.java class in the package.
 * 
 * For testing the following was used as input:
 * 
 * PROCESS   3000   RT     1     Real-Time Process A
 * PROCESS  1500  NM   5    Normal Process X
 * PROCESS     2500 RT  2    Real-Time Process B
 * PROCESS  1000      NM   1     Normal Process Y
 * PROCESS 2000 RT 3 Real-Time Process C
 * PROCESS    1200     NM 2 Normal Process Z
 * PROCESS   1800    RT   4  Real-Time Process D
 * PROCESS   1600 NM 4 Normal Process W
 * PROCESS  5000 RT 5 Real-Time Process E
 * PROCESS  1000 NM 3 Normal Process V
 * SHUTDOWN
 */

//imports to support multithreading
import java.util.*;
import java.util.concurrent.*;

public class Homework2_Smith {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Process> realtime = new ArrayList<>();
        List<Process> normal = new ArrayList<>();
        int idCounter = 1;

        // Grab user input 
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine().trim();
            // End program with SHUTDOWN command entered
            if (line.equals("SHUTDOWN")){
                break;
            }
            // Determine if process is RT or NM from input
            if (line.startsWith("PROCESS")) {
                // Splits line into 5 parts max, ignores whitespace 
                String[] parts = line.split("\\s+", 5); 
                
                // Parse the line and determine if all input fields were entered
                if (parts.length != 5) {
                    System.err.println("Invalid input line: " + line);
                    continue;
                }

                try { 
                    // Grab values of each part of input
                    int ms = Integer.parseInt(parts[1]);
                    boolean isRealTime = parts[2].equalsIgnoreCase("RT");
                    int priority = Integer.parseInt(parts[3]);
                    String name = parts[4].trim();

                    // Make a class for each process inputted
                    Process p = new Process(idCounter++, name, ms, isRealTime, priority);
                    
                    // Add each process to either RT or NM process' list
                    if (isRealTime) {
                        realtime.add(p);
                    } else {
                        normal.add(p);
                    }
                } catch (NumberFormatException e) {
                    // Error checking for invalid input
                    System.err.println("Invalid input line: " + line);
                }
            }
        }

        // Sort each process' list by the priority field
        realtime.sort(Comparator.comparingInt(p -> p.priority));
        normal.sort(Comparator.comparingInt(p -> p.priority));

        // Create ExecutorService to run at most 5 threads at once.
        // Run Real-time processes first
        ExecutorService rtExecutor = Executors.newFixedThreadPool(5);
        for (Process p : realtime) {
            rtExecutor.submit(p);
        }
        rtExecutor.shutdown();

        try{
            // Waits for all real-time processes to finish
            rtExecutor.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS); 
        } catch (InterruptedException e) {
            // Handle exception
            e.printStackTrace();
        }

        // Run the normal processes after real-time processes finish
        ExecutorService nExecutor = Executors.newFixedThreadPool(5);
        for (Process p : normal) {
            nExecutor.submit(p);
        }
        nExecutor.shutdown();

        try{
            // Waits for all normal processes to finish
            nExecutor.awaitTermination(Long.MAX_VALUE, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            // Handle exception
            e.printStackTrace();
        }
    }
}
